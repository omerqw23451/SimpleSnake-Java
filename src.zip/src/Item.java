import java.awt.*;

//Represents collectible items on the game board.
public class Item extends GameObject {
    public Item(int x, int y) {
        super(x, y); // Inherits x and y from GameObject.
    }

    @Override
    public void draw(Graphics g) { // Defines how an item is drawn (e.g., colored red).
        g.setColor(Color.RED); // Items will be colored red for visibility
        g.fillRect(x * GameBoard.CELL_SIZE, y * GameBoard.CELL_SIZE, GameBoard.CELL_SIZE, GameBoard.CELL_SIZE);
    }
}
