
//Defines the directions in which the snake can move.
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
