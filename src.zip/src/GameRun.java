import javax.swing.JFrame;
import javax.swing.SwingUtilities;

//Sets up the game window and starts the game.
public class GameRun extends JFrame {
    public GameRun() { // Constructor that creates the game window, adds the GameBoard, and makes it visible.
        setTitle("Simple Snake Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        GameBoard board = new GameBoard();
        add(board);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        board.placeItem(); // Ensure the board is visible and sized before placing items
    }


    public static void main(String[] args) { // The entry point of the application, which invokes the GameRun constructor.
        SwingUtilities.invokeLater(() -> new GameRun());
    }


}
