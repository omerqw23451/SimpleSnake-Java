
//Serves as a base for all drawable game objects, providing common attributes and operations.
public abstract class GameObject implements Drawable {
    protected int x, y; //Position coordinates on the game board.

    public GameObject(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Basic position access methods
    public int getX() { return x; }  // Return the object's position.
    public int getY() { return y; } // Return the object's position.
}
