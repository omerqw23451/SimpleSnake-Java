import java.awt.*;
import java.util.LinkedList;

//Represents the player-controlled snake.
public class Snake extends GameObject {

    private LinkedList<GameObject> body = new LinkedList<>(); //  containing the segments of the snake.
    private Direction direction = Direction.RIGHT; //The current movement direction.

    public Snake(int initialX, int initialY) {
        super(initialX, initialY);
        // Initialize the head as a distinct object if necessary or add initial body parts explicitly excluding 'this'.
        grow(); // Add initial body segments. Ensure this does not add 'this'.
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public boolean move() { // Updates the snake's position based on its direction, checks for self-collision and boundary conditions.
        // Get the current head position
        int headX = body.getFirst().getX();
        int headY = body.getFirst().getY();

        // Determine the new head position based on the current direction
        switch (direction) {
            case UP: headY -= 1; break;
            case DOWN: headY += 1; break;
            case LEFT: headX -= 1; break;
            case RIGHT: headX += 1; break;
        }

        // Check for boundaries
        if (headX < 0 || headX >= (800 / GameBoard.CELL_SIZE) || headY < 0 || headY >= (600 / GameBoard.CELL_SIZE)) {
            return false; // Game over or prevent movement
        }

        // Check for self-collision
        for (int i = 0; i < body.size(); i++) {
            GameObject segment = body.get(i);
            if (headX == segment.getX() && headY == segment.getY()) {
                // Collision detected, game should end
                return false; // Indicate game over
            }
        }

        // Insert a new head at the calculated position
        body.addFirst(new GameObject(headX, headY) {
            @Override
            public void draw(Graphics g) {
                g.setColor(Color.GREEN);
                g.fillRect(x * GameBoard.CELL_SIZE, y * GameBoard.CELL_SIZE, GameBoard.CELL_SIZE, GameBoard.CELL_SIZE);
            }
        });

        // Remove the last segment to maintain the snake's length
        body.removeLast();

        // If no collision, return true to indicate the game can continue
        return true;
    }




    public void grow() { //Adds a segment to the snake, allowing it to grow.
        // This method should add a new segment at the correct location.
        GameObject tail = body.peekLast();
        if(tail != null) {
            body.add(new GameObject(tail.getX(), tail.getY()) {
                @Override
                public void draw(Graphics g) {
                    g.setColor(Color.GREEN);
                    g.fillRect(x * GameBoard.CELL_SIZE, y * GameBoard.CELL_SIZE, GameBoard.CELL_SIZE, GameBoard.CELL_SIZE);
                }
            });
        } else {
            // This case handles adding the first segment if the body is empty.
            // Adjust the position as needed to place it correctly relative to the head.
            body.add(new GameObject(x, y) {
                @Override
                public void draw(Graphics g) {
                    g.setColor(Color.GREEN);
                    g.fillRect(x * GameBoard.CELL_SIZE, y * GameBoard.CELL_SIZE, GameBoard.CELL_SIZE, GameBoard.CELL_SIZE);
                }
            });
        }
    }

    @Override
    public void draw(Graphics g) { // Implements how the snake is drawn, iterating over its body segments.
        for (int i = 0; i < body.size(); i++) {
            GameObject segment = body.get(i);
            segment.draw(g);
        }
    }

    public LinkedList<GameObject> getBody() {
        return body;
    } //Returns the LinkedList representing the snake's body.


}
