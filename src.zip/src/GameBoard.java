import javax.swing.*;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import java.util.Random;

//The main component where the game logic is processed and visual elements are drawn.
public class GameBoard extends JPanel implements KeyListener{
    public static final int CELL_SIZE = 25;
    private Snake snake; // The player-controlled snake.
    private ArrayList<Drawable> drawables = new ArrayList<>(); // A collection of all drawable elements.
    private List<Item> items = new ArrayList<>(); // A collection of collectible items.
    private Random random = new Random(); // Used for generating random item positions.

    public GameBoard() { // Constructor that initializes the game, sets up key listeners, and starts the game loop.
        setPreferredSize(new Dimension(800, 600));
        snake = new Snake(10, 10);
        drawables.add(snake);
        setFocusable(true);
        addKeyListener(this);

        // Initialize items on the board
        placeItem(); // Ensure at least one item is placed when the game starts

        Timer timer = new Timer(100, e -> {
            boolean gameContinues = snake.move();
            if (!gameContinues) {
                ((Timer)e.getSource()).stop(); // Stop the game
                JOptionPane.showMessageDialog(this, "Game Over!", "Game Over", JOptionPane.ERROR_MESSAGE);
                // Here, you could also implement additional logic to restart the game or exit
            }
            checkItemCollection(snake);
            repaint();
        });
        timer.start();
    }


    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                snake.setDirection(Direction.UP);
                break;
            case KeyEvent.VK_DOWN:
                snake.setDirection(Direction.DOWN);
                break;
            case KeyEvent.VK_LEFT:
                snake.setDirection(Direction.LEFT);
                break;
            case KeyEvent.VK_RIGHT:
                snake.setDirection(Direction.RIGHT);
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) { }

    @Override
    public void keyTyped(KeyEvent e) { }


    public void checkItemCollection(Snake snake) { // Checks if the snake collects an item, triggers growth, and places a new item.
        GameObject head = snake.getBody().getFirst(); // Now accessible
        Item collectedItem = null;
        for (int i = 0; i < items.size(); i++) {
            Item item = items.get(i);
            if (head.getX() == item.getX() && head.getY() == item.getY()) {
                collectedItem = item;
                break;
            }
        }
        if (collectedItem != null) {
            snake.grow();
            items.remove(collectedItem);
            drawables.remove(collectedItem);
            placeItem(); // Optionally place a new item
        }
    }


    public void placeItem() { //  Places a new item on the board at a random position.
        int boardWidth = 800 / CELL_SIZE - 1; // -1 to ensure inside border
        int boardHeight = 600 / CELL_SIZE - 1; // -1 to ensure inside border

        // Generate random coordinates for the item within the game board's boundaries
        int x = random.nextInt(boardWidth);
        int y = random.nextInt(boardHeight);

        // Create and place the new item
        Item item = new Item(x, y);
        items.add(item);
        drawables.add(item);
    }

    @Override
    protected void paintComponent(Graphics g) {  //Overridden to draw all drawable elements on the board. Key event methods
        super.paintComponent(g);
        for (Drawable drawable : drawables) {
            drawable.draw(g);
        }
    }

}
