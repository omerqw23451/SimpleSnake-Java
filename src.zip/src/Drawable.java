
//Establishes a contract for objects that can be drawn on the game board.
public interface Drawable {

    void draw(java.awt.Graphics g);     //Required for implementing classes to define how they are drawn.
}
